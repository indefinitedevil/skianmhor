<?php
//overidden by build for production env
$insiteConfig = array(
	'insiteAPIServerBase' => 'https://my.insite.io',
    'insiteUIServerBase' => '//my.insite.io',
	'insiteRTScriptBase' => '//s3.amazonaws.com/insite-sites'
);
