<?php

$insiteConfig = array(
    'insiteAPIServerBase' => 'http://localhost:8080',
    'insiteUIServerBase' => '//localhost:8080',
    'insiteRTScriptBase' => '//s3.amazonaws.com/insite-sites-test'
);
