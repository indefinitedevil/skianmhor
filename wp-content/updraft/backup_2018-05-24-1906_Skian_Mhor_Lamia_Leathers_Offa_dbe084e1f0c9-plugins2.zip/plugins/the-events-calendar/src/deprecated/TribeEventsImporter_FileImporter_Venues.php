<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Importer__File_Importer_Venues' );


	class TribeEventsImporter_FileImporter_Venues extends Tribe__Events__Importer__File_Importer_Venues {

	}