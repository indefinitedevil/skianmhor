<?php


/**
 * Class Tribe__Events__Ajax__Operations
 *
 * Handles The Events Calendar specific class operations.
 */
class Tribe__Events__Ajax__Operations extends Tribe__Ajax__Operations {
}