<?php

/**
 * No Replies Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php _e( 'Oh bother! No replies were found here!', 'bbpress' ); ?></p>
</div>
